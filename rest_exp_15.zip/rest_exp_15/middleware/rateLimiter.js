const rateLimit = require('express-rate-limit');

// Allow max 5 requests per minute per IP
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 5,
  message: {
    success: false,
    message: 'Too many requests! Please try again after a minute ⏳'
  }
});

module.exports = limiter;

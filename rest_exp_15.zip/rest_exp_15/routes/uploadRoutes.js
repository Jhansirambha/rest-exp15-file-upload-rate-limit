const express = require('express');
const upload = require('../middleware/uploadMiddleware');
const limiter = require('../middleware/rateLimiter');
const router = express.Router();

// POST: Upload a file (with rate limiting)
router.post('/file', limiter, upload.single('file'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: 'No file uploaded ❌' });
    res.status(200).json({
      message: 'File uploaded successfully ✅',
      filename: req.file.filename,
      path: req.file.path
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
